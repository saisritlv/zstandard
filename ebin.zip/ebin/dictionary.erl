-module(dictionary).

-export([create/1]).

create([]) -> ok;
create([Segment | Tail]) ->
    file:make_dir(Segment),
    ets:foldl(fun(Element, Nr) ->
                      file:write_file(atom_to_list(Segment) ++ "/" ++ atom_to_list(Segment) ++ "_" ++ integer_to_list(Nr), term_to_binary(Element)),
                          Nr + 1
              end,0, Segment),
    create(Tail).
