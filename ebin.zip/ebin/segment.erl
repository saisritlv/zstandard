-module(segment).
%seg13_18.mbi

-export([load_all_segments/0,
         create_from_index_files/2,
         create_segment/2,
         create_all_segments/1,
         insert_index_files/2,
         save_to_file/1]).

-define(max_broker_index, 511).

load_all_segments() ->
    %% assume all segments in same directory
    lists:map(fun(Nr) ->
                      {ok, Seg} = ets:file2tab("seg" ++ integer_to_list(Nr) ++ ".mbin"),
                      Seg
              end,lists:seq(1,13)).


%% segment:create_all_segments("/home/enillju/erl/mt/index2seg/second_set_double_mobiles")
create_all_segments(Path) ->
    lists:foreach(fun(SegmentNumber) ->
                          create_from_index_files(Path, SegmentNumber)
                  end,lists:seq(1,13)).


%% Path "", SegmentNumber :: integer
-spec create_from_index_files(Path, SegmentNumber) -> any() when
      Path  :: string(), %% "/home/enillju/erl/mt/index2seg/second_set_double_mobiles"
      SegmentNumber :: integer(). %% 13
create_from_index_files(Path, SegmentNumber) ->
    Segment = create_segment(Path, SegmentNumber),
    insert_index_files(Segment, Path),
    save_to_file(Segment),
    ets:delete(Segment).

create_segment(Path, SegmentNumber) ->
    %% Assume the max index exist (it should) to copy ets table details for new segment
    SegmentName = "seg" ++ integer_to_list(SegmentNumber),
    {ok, Info} = ets:tabfile_info(Path ++ "/" ++ SegmentName ++ "_" ++ integer_to_list(?max_broker_index) ++ ".mbin"),
    Type = proplists:get_value(type, Info),
    KeyPos = proplists:get_value(keypos, Info),

    ets:new(list_to_atom(SegmentName), [named_table, Type, {keypos, KeyPos}]).

insert_index_files(Segment, Path) ->

    lists:foreach( fun(SegmentIndex) ->
                           {ok, SegIndexTab} = ets:file2tab(Path ++ "/" ++ SegmentIndex ++ ".mbin"),
                           Objects = ets:tab2list(SegIndexTab),
                           ets:insert(Segment, Objects)
                   end, generate_index_tabs(Segment)).

save_to_file(Segment) ->
    ets:tab2file(Segment, atom_to_list(Segment) ++ ".mbin").

generate_index_tabs(Segment) ->

    lists:map(
      fun(Index)->
              atom_to_list(Segment) ++ "_" ++ integer_to_list(Index)
      end,
      lists:seq(0, ?max_broker_index)).
