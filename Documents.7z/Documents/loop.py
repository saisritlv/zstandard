import os 
import time
import zstandard as zstd
import glob

def main():
 segments = '/home/sai/Documents/segments'
 dicts = '/home/sai/Documents/dictionaries'
 folder = []
 data = []
 rootnames=[]
 for root,dirs,files in os.walk(segments, topdown=True):
   for name in sorted(dirs):
      #print(name)
      tmp = os.path.join(root,name)
      folder.append(tmp)
      rootnames.append(name)
      #print tmp
      #print(rootnames)
 for root,dirs,files in os.walk(dicts, topdown=True):
   for name in sorted(files):
      tmp = os.path.join(root,name)
      data.append(tmp)
      #print tmp
 for a,b,c in zip(data,folder,rootnames):
   n = []
   sizeinfo_if = os.stat(b)
   #print('Size of input file is :', sizeinfo_if.st_size, 'Bytes')
   fh_output = open('output.zst','wb')
   #decompfile = open('%s' %c, 'wb')
   dictionary = open(a,'r')
   #print(dictionary)
   dict_data = zstd.ZstdCompressionDict(dictionary.read())
   cctx = zstd.ZstdCompressor(dict_data=dict_data)
   dctx = zstd.ZstdDecompressor(dict_data=dict_data)
   #print b
   for root,dirs,files in os.walk(b, topdown=True):
    for temp in sorted(files):
        #print temp
        xpath = os.path.join(root,temp)
        #print xpath
        
	with open(xpath,'rb') as fh:
		data1 = fh.read().replace('\n',' ')
       		n = data1.split(b'bWLA')

		initial_timestamp = time.time()
        	for i in n[::-1]:	
        		compressed = cctx.compress(i)
		end_timestamp = time.time()
	
		with cctx.write_to(fh_output) as compressor:
			compressor.write(compressed) 
  
 print('Time taken to compress:', end_timestamp - initial_timestamp)
 sizeinfo_of = os.stat('output.zst')
 print('size of compressed file:', sizeinfo_of.st_size, 'bytes')
 #print('decompression time', dend_time - dstart_time)
 
main()
   



















