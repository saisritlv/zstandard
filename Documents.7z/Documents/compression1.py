# import zstd library for zstandard simple api access and Compress
import os
import time
import zstandard as zstd

def compress(): 
    n = []
    compressed = []
    sizeinfo_if = os.stat('/home/sai/Documents/segments/')
    print('Size of input file is :', sizeinfo_if.st_size, 'Bytes')
    
    path = '/home/sai/Documents/segments/'
    
    files = os.listdir(path)
    
    fh_output = open('com.zst','wb')
    
    cctx = zstd.ZstdCompressor()
    initial_timestamp = time.time()
    
    
    for x in files:
	xpath = os.path.join(path,x)
	with open(xpath,'rb') as fh:
		data = fh.read().replace('\n',' ')
       		n = data.split(b'bWLA')
        	for a in n:
        		compressed = cctx.compress(a)
			print(a)
			print(compressed) 
		with cctx.write_to(fh_output) as compressor:
				compressor.write(compressed) 
                        
    end_timestamp = time.time()

    print('Time taken to compress:', end_timestamp - initial_timestamp)

    sizeinfo_of = os.stat('compress.zst')
    print('size of compressed file:', sizeinfo_of.st_size, 'bytes')
    

def list_files(dir):
    for dirs in dir:
	files = os.walk(dir).next()[2]
	if(len(files) > 0):
	    for file in files:
		compress()
def main():
 if (_name_=="_main_"):
	list_files(segments)



