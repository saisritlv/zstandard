# import zstd library for zstandard simple api access and Compress
import os
import time
import zstandard as zstd

def main():
    # determine size of input file
    sizeinfo_if = os.stat('SEG1')
    print('Size of input file is :', sizeinfo_if.st_size, 'Bytes')

    # make sure zstd is installed and running
    #ver = zstd.__version__;
    #print('Zstd version : ', ver)

    # Zstd compressor object creation
    cctx = zstd.ZstdCompressor()
    #dctx = zstd.ZstdDecompressor()
    initial_timestamp = time.time()

    # Get byte sized chucks from in File, compress and write to out file
    with open('SEG1', 'rb') as fh_input , open('output.zst','wb') as fh_output: 
        byte_chunk = fh_input.read()
        while byte_chunk:
            #bdata=bytes(str.encode(byte_chunk))
            compressed = cctx.compress(byte_chunk)
	    with cctx.write_to(fh_output) as compressor:
		compressor.write(compressed)
	    byte_chunk = fh_input.read()
        
    """with open('input', 'wb')as my_input, open('output.zst','rb') as f:
	sizeinfo_out = os.stat('output.zstd')
	print('size of compressed file:', sizeinfo_out.st_size,'bytes')
	chunk = f.readline()
	while chunk:
	    	decompressed = dctx.decompress(chunk)
    		with dctx.stream_writer(my_input) as decompressor:
			decompressor.write(decompressed)
		chunk = f.read()"""
    end_timestamp = time.time()
    
    print('Time taken to compress:', end_timestamp - initial_timestamp)
    
    sizeinfo_of = os.stat('output.zst')
    print('Size of compressed file:', sizeinfo_of.st_size, 'bytes')

main()
