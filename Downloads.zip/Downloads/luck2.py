# import zstd library for zstandard simple api access and Compress
import os
import time
import zstandard as zstd


def main():    
# determine size of input file
    sizeinfo_if = os.stat('dict trail')
    print('Size of input file is :', sizeinfo_if.st_size, 'Bytes')
    
    path = '/home/sai/Documents/dict trail/'
    
    files = os.listdir(path)
    
    fh_output = open('dictoutput.zst','wb')
    dict_file = open('SEG1','r')
    dict_data = zstd.ZstdCompressionDict(dict_file.read())
    cctx = zstd.ZstdCompressor(dict_data=dict_data)
    
    initial_timestamp = time.time()
    
    for x in files:
	xpath = os.path.join(path,x)
	with open(xpath,'rb') as fh:
		data = fh.read().replace('\n',' ')
       		n = data.split(b'bWLA')
        	for a in n:
        		compressed = cctx.compress(a)
			print(a)
			print("hii")
			print(compressed)
			with cctx.write_to(fh_output) as compressor:
				compressor.write(compressed)
			
	           
    end_timestamp = time.time()

    print('Time taken to compress:', end_timestamp - initial_timestamp)
    
main()
