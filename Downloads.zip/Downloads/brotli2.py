"""Functions to compress and decompress data using the Brotli library."""

import _brotli


# The library version.
__version__ = _brotli.__version__

# The compression mode.
MODE_GENERIC = _brotli.MODE_GENERIC
MODE_TEXT = _brotli.MODE_TEXT
MODE_FONT = _brotli.MODE_FONT

# The Compressor object.
Compressor = _brotli.Compressor

# The Decompressor object.
Decompressor = _brotli.Decompressor

# Compress a byte string.
def compress(data, mode=MODE_GENERIC, quality=11, lgwin=22, lgblock=0):
	data = open('agile.pdf','rb') 
	output = open('br.br','wb')   

	Compressor = Compressor(mode=mode, quality=quality, lgwin=lgwin,
                            lgblock=lgblock)
        return compressor.process(data) + compressor.finish()


# Decompress a compressed byte string.
decompress = _brotli.decompress

# Raised if compression or decompression fails.
error = _brotli.error
