# import zstd library for zstandard simple api access and Compress
import os
import time
import zstd

def main():
    sizeinfo_if = os.stat('agile.pdf')
    print('Size of input file is :', sizeinfo_if.st_size, 'Bytes')

    ver = zstd.version()
    print('Zstd version : ', ver)
    
    
    with open('agile.pdf','rb') as fh_input, open('output.zstd','wb') as fh_output:
	initial_timestamp = time.time()
	byte_chunk = fh_input.read(4576)
	while byte_chunk:
		compressed = zstd.compress(byte_chunk)
		
		byte_chunk = fh_input.read(4576)
	fh_output.write(compressed)
	end_timestamp = time.time()

    print('Time taken to compress:', end_timestamp - initial_timestamp)
    sizeinfo_of = os.stat('output.zstd')
    print('Size of output File is:', sizeinfo_of.st_size, 'Bytes')

main()
