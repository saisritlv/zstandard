# import zstd library for zstandard simple api access and Compress
import os
import time
import zstandard as zstd

def main():
    n = []
   
# determine size of input file
    sizeinfo_if = os.stat('seg1_435.mbin')
    print('Size of input file is :', sizeinfo_if.st_size, 'Bytes')
    
# make sure zstd is installed and running
    #ver = zstd.__version__;
    #print('Zstd version : ', ver)
    
    fh_output = open('ft.zst','wb')
    dict = zstd.ZstdCompressionDict(SEG1)
    cctx = zstd.ZstdCompressor(dict)
    initial_timestamp = time.time()
    
# Get byte sized chucks from in File, compress and write to out file
    
    with open('seg1_435.mbin', 'rb') as fh_input:	
       	data = fh_input.read().replace('\n',' ')
       	n = data.split(b'bWLA')
        for a in n[:-1]:
        	compressed = zstd.compress(a)
		with cctx.write_to(fh_output) as compressed:
			compressed.write(cctx.compress(dict))
	#compressed = cctx.compress(dict)
                
    end_timestamp = time.time()

    print('Time taken to compress:', end_timestamp - initial_timestamp)
    
    
    
main()
