import time
import os

import _brotli

def main():
    # determine size of input file
    sizeinfo_if = os.stat('sai.txt')
    print('Size of input file is :', sizeinfo_if.st_size, 'Bytes')

    ver = _brotli.__version__;
    print('Brotli version : ', ver)
	
    #decompressed_data = _brotli.decompress(compressed_data)
    
    compressor = _brotli.Compressor
    initial_timestamp = time.time()

    # Get byte sized chucks from in File, compress and write to out file
    with open('sai.txt', 'rb') as fh_input, open('brotli.br','wb')as fh_output:
        chunk = fh_input.read(1)
        while chunk:
            compressed = compressor.compress(chunk)
	    fh_output.write(compressed)
	    chunk = fh_output.read(1)
    end_timestamp = time.time()

    print('Time taken to compress:', end_timestamp - initial_timestamp)
    sizeinfo_of = os.stat('brotli.br')
    print('Size of output File is:', sizeinfo_of.st_size, 'Bytes')

main()
