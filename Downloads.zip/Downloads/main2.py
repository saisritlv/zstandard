# import zstd library for zstandard simple api access and Compress
import os
import time
import zstandard as zstd

def main():
    # determine size of input file
    sizeinfo_if = os.stat('seg1_435.mbin')
    print('Size of input file is :', sizeinfo_if.st_size, 'Bytes')

    # make sure zstd is installed and running
    ver = zstd.__version__;
    print('Zstd version : ', ver)

    # Zstd compressor object creation
    cctx = zstd.ZstdCompressor()
    initial_timestamp = time.time()

    # Get byte sized chucks from in File, compress and write to out file
    with open('seg1_435.mbin', 'rb') as fh_input , open('output.zstd','wb') as fh_output:
        byte_chunk = fh_input.read(1)
        while byte_chunk:
            #bdata=bytes(str.encode(byte_chunk))
            compressed = cctx.compress(byte_chunk)
	    with cctx.write_to(fh_output) as compressor:
		compressor.write(byte_chunk)
	    byte_chunk = fh_input.read(1)
    end_timestamp = time.time()

    print('Time taken to compress:', end_timestamp - initial_timestamp)
    sizeinfo_of = os.stat('output.zstd')
    print('Size of output File is:', sizeinfo_of.st_size, 'Bytes')

main()
