-module(benchmark).

-export([full/0,
         compress_zlib/1,
         time_zlib/1,

         compress_zstd/1,
         time_zstd/1,

        compress_null/1,
        time_null/1]).

full() ->
    Segments = segment:load_all_segments(),
    {Microseconds, ok} = timer:tc(benchmark, compress_zlib, [Segments]),
    {Microseconds, Segments}.

compress_null(Segments) ->
    lists:foldl(fun (Segment, SizeSeg) ->
                        SizeSeg + ets:foldl(fun (Element,Size) ->
                                                 D = term_to_binary(Element),
                                                 C = D,
                                                 Size + byte_size(C)
                                         end,0, Segment)
                end, 0, Segments).

compress_zlib(Segments) ->
    lists:foldl(fun (Segment, SizeSeg) ->
                        SizeSeg + ets:foldl(fun (Element,Size) ->
                                                 D = term_to_binary(Element),
                                                 C = zlib:compress(D),
                                                 %% compress 2 in MME
                                                 zlib:compress(D),

                                                 zlib:uncompress(C),
                                                 Size + byte_size(C)
                                         end,0, Segment)
                end, 0, Segments).

compress_zstd(Segments) ->
    lists:foldl(fun (Segment, SizeSeg) ->
                        SizeSeg + ets:foldl(fun (Element,Size) ->
                                                 D = term_to_binary(Element),
                                                 C = zstd:compress(D),
                                                 %% compress 2 in MME
                                                 zstd:compress(D),

                                                 zstd:decompress(C),
                                                 Size + byte_size(C)
                                         end,0, Segment)
                end, 0, Segments).


time_alg(Algorithm, Segments) ->
    Function = list_to_atom("compress_" ++ atom_to_list(Algorithm)),
    {Microseconds, ZlibSize} = timer:tc(benchmark, Function, [Segments]).

time_zstd(Segments) ->
    time_alg(zstd, Segments).

time_zlib(Segments) ->
    time_alg(zlib, Segments).
time_null(Segments) ->
    time_alg(null, Segments).
