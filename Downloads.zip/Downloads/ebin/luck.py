# import zstd library for zstandard simple api access and Compress
import os
import time
import zstd
import filemapper as fm


def main():
    n = []
# determine size of input file
    
# make sure zstd is installed and running
    ver = zstd.version();
    print('Zstd version : ', ver)

    initial_timestamp = time.time()
    
# Get byte sized chucks from in File, compress and write to out file
    all_files = fm.load('ebin')
    for i in all_files:
	with open('seg%s'%(i), 'rb') as fh_input:
		sizeinfo_if = os.stat(fh_input)
    		print('Size of input file is :', sizeinfo_if.st_size, 'Bytes')

        	data = fh_input.read().replace('\n',' ')
        	n = data.split(b'bWLA')
		#dict_data = zstd.ZstdCompressionDict(n)
        	#for a in n[:-1]:
            	compressed = zstd.compress(n)
                
    end_timestamp = time.time()

    print('Time taken to compress:', end_timestamp - initial_timestamp)
    
    
    
main()
