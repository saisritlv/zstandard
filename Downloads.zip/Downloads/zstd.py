#!/usr/bin/python

import zstandard

cctx = zstd.ZstdCompressor()
compressed = cctx.compress(b'data to compress')

