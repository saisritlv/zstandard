# import zstd library for zstandard simple api access and Compress
import os
import time
import zstandard as zstd


def main(): 
    n = []
    sizeinfo_if = os.stat('/home/sai/Documents/seg1')
    print('Size of input file is :', sizeinfo_if.st_size, 'Bytes')
    path = '/home/sai/Documents/seg1'
    files = os.listdir(path)
    fh_output = open('%s.zst','wb') %c
    dictionary = open('SEG1','r')
    dict_data = zstd.ZstdCompressionDict(dictionary.read())
    cctx = zstd.ZstdCompressor(dict_data=dict_data)
    dctx = zstd.ZstdDecompressor(dict_data=dict_data)
    
    for x in b:
	xpath = os.path.join(b,x)
	with open(xpath,'rb') as fh:
		data = fh.read().replace('\n',' ')
       		n = data.split(b'bWLA')

		initial_timestamp = time.time()
        	for a in n[::-1]:
			print "hii"	
        		compressed = cctx.compress(a)
		end_timestamp = time.time()
	
		with cctx.write_to(fh_output) as compressor:
			compressor.write(compressed) 
    dstart_time = time.time()
    for i in compressed:		
       decompressed = dctx.decompress(compressed)
    dend_time = time.time()

    print('Time taken to compress:', end_timestamp - initial_timestamp)
    
    sizeinfo_of = os.stat('compressed.zst')
    print('size of compressed file:', sizeinfo_of.st_size, 'bytes')
    print('decompression time', dend_time - dstart_time)
main()
