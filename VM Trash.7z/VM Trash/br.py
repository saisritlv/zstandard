import brotli

compressed_data = 'saisri,hari,priya,karuna,nag,rao,tikkireddy'

decompressed_data = brotli.decompress(compressed_data)

d = brotli.Decompressor()
for chunk in chunks_of_compressed_data:
            some_compressed_data = d.decompress(chunk)

remaining_data = d.flush()

compressed = brotli.compress(uncompressed_data) 
