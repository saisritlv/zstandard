import zstandard as zstd
import time

def main():
	of = open('of.zst','wb')
	data = 'nijfirojfisdnmckwlfirof'
	dict_data = zstd.ZstdCompressionDict(data)
	cctx = zstd.ZstdCompressor()
	initial_timestamp = time.time()
	compressed = cctx.compress(dict_data)
	end_timestamp = time.time()
	with cctx.write_to(of) as compressor:
		compressor.write(compressed)
main()
