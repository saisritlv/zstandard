import sys

a = 1
b = 3
while (1):
	b = a
	c = b
	a++
end
