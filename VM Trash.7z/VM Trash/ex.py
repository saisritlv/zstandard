import os
import glob
dist=[]
folder_path = '/home/seg1'
for filename in glob.glob(os.path.join(folder_path, '*.mbin')):
  with open(filename, 'r') as f:
    text = f.read()
    print (filename)
    print (text)
    dist[filename]=text
    print dist[]
