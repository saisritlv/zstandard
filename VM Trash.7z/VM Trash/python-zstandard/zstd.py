#!/usr/bin/python

import io
import os
import random
import struct
import sys
import time
import zlib
import datetime

from zstd import *

#import zstandard as zstd

with open('sai.odt','rb')as f:
	def compress_stream_reader(chunks, zparams):
		zctx = zstd.ZstdCompressor(compression_params=zparams)
		initial_timestamp = time.time()
		for chunk in f:
			with zctx.stream_reader(chunk) as reader:
				while reader.read(16384):
					pass
		compressed = zctx.compress('f')
		end_timestamp = time.time()
		print('time difference is')
		print(end_timestamp - initial_timestamp)

def compress_stream_writer(chunks,zparams):
		zctx = zstd.ZstdCompressor(compression_params=zparams)
		for chunk in f:
			b=bio()
			with zctx.stream_writer(b) as compressor:
				compressor.write(chunk)
