# import zstd library for zstandard simple api access and Compress
import csv
import datetime
import time
import sys
import os
import io
import zlib
import struct
import random

#import zstandard as zstd
from zstd import *

def main(zparams):



    # set path of csv file to save  stats
    path = 'sai.odt'
    fh = open(path,"rb")


#ver = zstd.__version__;
#make sure zstd is installed and running
#print(ver)

#data and bytesData
data = 'jdfyfyufgdt';
bdata=bytes(str.encode(data))

#Zstd compressor object creation and initila timestamp
zctx = zstd.ZstdCompressor(comperssion_params=zparams)
initial_timestamp = time.time()

compressed = zctx.compress(bdata)
end_timestamp = time.time()
print('Time taken to compress:')
print(end_timestamp - initial_timestamp)



main()
