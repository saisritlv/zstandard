#!/bin/bash

set -e

$PYTHON setup.py install
